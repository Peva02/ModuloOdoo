# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class odoo670(models.Model):
#     _name = 'odoo670.odoo670'
#     _description = 'odoo670.odoo670'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
from odoo import models, fields, api

class coches670(models.Model):
	_name = 'odoo670.coches670'
	_description = 'Modelo coches670'

	name = fields.Char('Matricula',required=True)
	marca = fields.Char(string='Marca',required=True)
	precio = fields.Char(string='Precio',required=True)
